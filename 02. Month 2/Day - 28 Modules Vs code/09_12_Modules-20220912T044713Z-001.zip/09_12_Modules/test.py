def welcome():
    return f"Welcome to Module"

def dummy1():
    print("This is dummy module")