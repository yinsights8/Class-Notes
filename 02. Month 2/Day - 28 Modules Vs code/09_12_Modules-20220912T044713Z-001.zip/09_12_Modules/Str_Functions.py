def get_upper(str1):
    print("We are in the get_upper() function")
    return str1.upper()