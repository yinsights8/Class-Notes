def addition(a,b):
    print(f"We are in the addition function")
    return a + b


def subtract(a,b):
    print(f"We are in the subtraction function")
    return a - b

